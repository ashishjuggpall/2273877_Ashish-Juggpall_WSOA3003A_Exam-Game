using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private PlayerController playerController;
    private MultiDirectionalBallController multiDirectionalBallController;
    private DestroyBallController destroyBallController;

    Scene Level1;
    Scene Level2;
    Scene Level3;

    public GameObject Player;

    [Space]
    [Header("Ball Variants")]
    public GameObject NormalBall;
    public GameObject MultiDirectionalBall;
    public GameObject DestructableBall;

    [Space]
    [Header("Endgame Targets")]
    public GameObject EndGame1;
    public GameObject EndGame2;
    public GameObject EndGame3;

    [Space]
    [Header("Game UI Variants")]
    public GameObject AllGameUI;
    public GameObject NormalBallUI;
    public GameObject MultiDirectionalBallUI;
    public GameObject DestructableBallUI;

    [Space]
    [Header("Win & Lose UI")]
    public GameObject WinUI1;
    public GameObject LoseUI1;
    public GameObject WinUI2;
    public GameObject LoseUI2;
    public GameObject WinUI3;
    public GameObject LoseUI3;

    private bool IsScene1;
    private bool IsScene2;
    private bool IsScene3;
    public void Start()
    {
        playerController = GetComponent<PlayerController>();
        multiDirectionalBallController = GetComponent<MultiDirectionalBallController>();
        destroyBallController = GetComponent<DestroyBallController>();

        Scene CurrentScene = SceneManager.GetActiveScene();

        string SceneName = CurrentScene.name;

        //if Level1 is active 
        if (SceneName == "Level1")
        {
            IsScene1 = true;
            IsScene2 = false;
            IsScene3 = false;

            AllGameUI.SetActive(true);

            NormalBallUI.SetActive(true);
            MultiDirectionalBallUI.SetActive(false);
            DestructableBallUI.SetActive(false);

            WinUI1.SetActive(false);
            LoseUI1.SetActive(false);
        }

        //if Level2 is active
        if (SceneName == "Level2")
        {
            IsScene1 = false;
            IsScene2 = true;
            IsScene3 = false;

            AllGameUI.SetActive(true);

            NormalBallUI.SetActive(true);
            DestructableBallUI.SetActive(false);
            MultiDirectionalBallUI.SetActive(false);

            WinUI2.SetActive(false);
            LoseUI2.SetActive(false);
        }

        //if Level3 is active
        if (SceneName == "Level3")
        {
            IsScene1 = false;
            IsScene2 = false;
            IsScene3 = true;

            AllGameUI.SetActive(true);

            NormalBallUI.SetActive(true);
            MultiDirectionalBallUI.SetActive(false);
            DestructableBallUI.SetActive(false);

            WinUI3.SetActive(false);
            LoseUI3.SetActive(false);
        }

    }

    public void Update()
    {
        if (IsScene1 == true)
        {
            EndGame1.SetActive(true);

            MultiDirectionalBallUI.SetActive(false);
            DestructableBallUI.SetActive(false);
            //what appears and whats allowed when any of these balls and their ui are active

            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                NormalUI();
            }
        }

        if (IsScene2 == true)
        {
            EndGame2.SetActive(true);

            MultiDirectionalBallUI.SetActive(false);

            //what appears and whats allowed when any of these balls and their ui are active

            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                NormalUI();
            }

            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                BlazeUI();
            }
        }

        if (IsScene3 == true)
        {
            EndGame3.SetActive(true);

            //what appears and whats allowed when any of these balls and their ui are active

            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                NormalUI();
            }

            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                BlazeUI();
            }

            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                OmniUI();
            }
        }
    }

    public void NormalUI()
    {
        NormalBallUI.SetActive(true);
        MultiDirectionalBallUI.SetActive(false);
        DestructableBallUI.SetActive(false);
    }

    public void OmniUI()
    {
        MultiDirectionalBallUI.SetActive(true);
        NormalBallUI.SetActive(false);
        DestructableBallUI.SetActive(false);
    }

    public void BlazeUI()
    {
        DestructableBallUI.SetActive(true);
        NormalBallUI.SetActive(false);
        MultiDirectionalBallUI.SetActive(false);
    }
}
