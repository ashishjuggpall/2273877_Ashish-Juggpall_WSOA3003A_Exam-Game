using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DestroyBallController : MonoBehaviour
{
    public InputDataController inputData;

    public LayerMask ColliderLayer;

    private PlayerVisualEffectsController playerVFX;

    private Vector3 ClickedPosition;
    private Vector3 ReleasedPosition;
    private Vector3 Direction;

    private ShakeController shake;
    public GameObject Effect;

    [Space]
    [Header("Game Object Variables")]

    Rigidbody2D rigidBody;

    Camera Cam;
    public float MovementSpeed = 7f;
    public int ExplodeAbility = 6;

    public float VelocityTimeRemaining = 5f;
    public bool VelocityTimeRunning = false;

    public GameObject DestructionalBall;

    [Space]
    [Header("Game UI Variants")]
    public GameObject DestructionalBallUI;
    public GameObject BallCount1;
    public GameObject BallCount2;
    public GameObject BallCount3;
    public GameObject BallCount4;
    public GameObject BallCount5;
    public GameObject BallCount6;

    void Start()
    {
        VelocityTimeRunning = false;
        GetComponents();
        shake = GameObject.FindGameObjectWithTag("ScreenShake").GetComponent<ShakeController>();
    }

    void Update()
    {
        Scene CurrentScene = SceneManager.GetActiveScene();

        string SceneName = CurrentScene.name;

        if (SceneName == "Level2")
        {
            if (DestructionalBallUI.activeSelf)
            {
                if (ExplodeAbility <= 6)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(true);
                }

                if (ExplodeAbility <= 5)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 4)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }
                if (ExplodeAbility <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility < 0)
                {
                    BallCount1.SetActive(false);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    Destroy(gameObject);
                }

                else
                {
                    if (VelocityTimeRunning == false)
                    {
                        HandleMovement();
                    }
                }
            }
        }

        if (SceneName == "Level3")
        {
            if (DestructionalBallUI.activeSelf)
            {
                if (ExplodeAbility <= 6)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(true);
                }

                if (ExplodeAbility <= 5)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 4)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }
                if (ExplodeAbility <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                if (ExplodeAbility < 0)
                {
                    BallCount1.SetActive(false);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                }

                else
                {
                    if (VelocityTimeRunning == false)
                    {
                        HandleMovement();
                    }
                }
            }
        }
    }

    public void FixedUpdate()
    {
        if (VelocityTimeRunning)
        {
            if (VelocityTimeRemaining > 0)
            {
                VelocityTimeRemaining -= Time.deltaTime;
            }

            else
            {
                ResetPlayerPosition();
                VelocityTimeRemaining = 3f;
                VelocityTimeRunning = false;
            }
        }
    }

    void GetComponents()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        Cam = GetComponent<Camera>();

        playerVFX = GetComponent<PlayerVisualEffectsController>();
    }

    void HandleMovement()
    {
        //When mouse is clicked
        if (inputData.isPressed == true)
        {
            ClickedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            ClickedPosition = new Vector3(rigidBody.position.x, rigidBody.position.y, 0f);
            //ClickedPosition = new Vector3(ClickedPosition.x, ClickedPosition.y, 0f);

            //ResetPlayerPosition();
            ResetPlayerPosition();

            //playerVFX.SetDotStartPosition(ClickedPosition);

            playerVFX.ActivateDotState(true);

            playerVFX.ChangeBallTrailState(false, 0f);

            Debug.Log(Input.mousePosition);
            Debug.Log(ClickedPosition);
        }

        //when mouse is clicked and held
        if (inputData.isHeld == true)
        {
            playerVFX.SetDotPosition(ClickedPosition, Camera.main.ScreenToWorldPoint(Input.mousePosition));
            playerVFX.MakeBallPulse();
        }

        //when mouse is released after being held
        if (inputData.isReleased == true)
        {
            VelocityTimeRunning = true;
            ReleasedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            ReleasedPosition = new Vector3(ReleasedPosition.x, ReleasedPosition.y, 0f);
            Debug.Log(Input.mousePosition);
            Debug.Log(ReleasedPosition);

            playerVFX.ActivateDotState(false);
            playerVFX.ResetBallSize();

            playerVFX.ChangeBallTrailState(true, 0.7f);

            CalculateDirection();

            MovePlayerInDirection();

            ExplodeAbility--;
        }
    }

    //Claculate decision and power based on click and drag
    void CalculateDirection()
    {
        Direction = (ReleasedPosition - ClickedPosition).normalized;
    }

    //shoots ball in direction of choice
    void MovePlayerInDirection()
    {
        rigidBody.velocity = Direction * MovementSpeed;
    }

    //origninally resets player, but now it just stops player in place so line renderer still connects 
    void ResetPlayerPosition()
    {
        rigidBody.velocity = Vector3.zero;
    }
    ///void ResetPlayerPosition()
    ///{
    ///transform.position = ClickedPosition;
    ///rigidbody.velocity = Vector3.zero;
    ///}
    ///

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Base Wall"))
        {
            Vector2 NormalWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, NormalWall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }

        if (collision.gameObject.CompareTag("Breakable Wall"))
        {
            Vector2 BreakableWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, BreakableWall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;

            Instantiate(Effect, transform.position, Quaternion.identity);

            Destroy(collision.gameObject);

            shake.CamShake();
        }

        if (collision.gameObject.CompareTag("Normal Ball"))
        {
            Vector2 NormalWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, NormalWall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }

        if (collision.gameObject.CompareTag("MultiDirectional Ball"))
        {
            Vector2 MultiDirectionalBall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, MultiDirectionalBall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }
    }

    bool HitBlockCheck()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit2D WallHit = Physics2D.Raycast(ray.origin, ray.direction, 100f, ColliderLayer);

        return WallHit;
    }
}

