using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerVisualEffectsController : MonoBehaviour
{
    public GameObject Dots;
    public int DotCount;

    [Space]
    [Header("Line Variables")]

    public AnimationCurve FollowCurve;
    public float FollowingSpeed;

    [Space]
    [Header("Ball Pulse Variables")]
    public AnimationCurve ExpandingCurve;
    public float ExpandingCount;
    public float ExpandingSpeed;

    Vector3 StartingSize;
    Vector3 TargetSize;
    float ScrollAmount;

    TrailRenderer trailRenderer;

    private float DotGap;

    GameObject[] DotArray;
    
    void Start()
    {
        //the number of dots in the line
        DotGap = 1f / DotCount;

        GetComponents();

        EmitPulseEffectVariables();

        SpawnDots();
    }

    void GetComponents()
    {
        trailRenderer = GetComponentInChildren<TrailRenderer>();
    }

    void Update()
    {
        
    }

    void EmitPulseEffectVariables()
    {
        StartingSize = transform.localScale;
        TargetSize = StartingSize * ExpandingCount;
    }

    void SpawnDots()
    {
        DotArray = new GameObject[DotCount];

        for(int i = 0; i < DotCount; i++)
        {
            GameObject dot = Instantiate(Dots);
            dot.SetActive(false);
            DotArray[i] = dot;
        }
    }

    public void SetDotPosition(Vector3 StartPosition, Vector3 EndPosition)
    {
        for(int i = 0; i < DotCount; i++)
        {
            Vector3 dotPosition = DotArray[i].transform.position;
            Vector3 TargetPosition = Vector2.Lerp(StartPosition, EndPosition, (i + 1) * DotGap);

            float Smoothnessspeed = (1f - FollowCurve.Evaluate(i * DotGap)) * FollowingSpeed;

            //DotArray[i].transform.position = TargetPosition;

            DotArray[i].transform.position = Vector2.Lerp(dotPosition, TargetPosition, Smoothnessspeed * Time.deltaTime);
        }
    }

    public void ActivateDotState(bool state)
    {
        for(int i = 0; i < DotCount; i++)
        {
            DotArray[i].SetActive(state);
        }
    }

    //public void SetDotStartPosition(Vector3 Position)
    //{
    //for(int i = 0; i < dotcount; i++)
    //{
    //DotArray[i].tranform.position = position;
    //}
    //}

    public void MakeBallPulse()
    {
        ScrollAmount += Time.deltaTime * ExpandingSpeed;

        float percentage = ExpandingCurve.Evaluate(ScrollAmount);

        transform.localScale = Vector2.Lerp(StartingSize, TargetSize, percentage);
    }

    public void ResetBallSize()
    {
        transform.localScale = StartingSize;
        ScrollAmount = 0f;
    }

    public void ChangeBallTrailState(bool Emitting, float Time)
    {
        trailRenderer.emitting = Emitting;
        trailRenderer.time = Time;
    }
}
