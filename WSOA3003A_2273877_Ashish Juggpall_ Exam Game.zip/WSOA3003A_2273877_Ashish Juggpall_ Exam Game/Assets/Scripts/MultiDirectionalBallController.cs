using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MultiDirectionalBallController : MonoBehaviour
{
    public InputDataController inputData;

    public LayerMask ColliderLayer;

    private PlayerVisualEffectsController playerVFX;

    private Vector3 ClickedPosition;
    private Vector3 ReleasedPosition;
    private Vector3 Direction;

    private ShakeController shake;
    public GameObject Effect;

    [Space]
    [Header("Game Object Variables")]

    Rigidbody2D rigidBody;

    Camera Cam;

    public float MovementSpeed = 15f;
    public int AbilityCount = 7;

    public bool IsStuck = true;

    [Space]
    [Header("Force Fields")]

    public GameObject RedForceField;
    public GameObject YellowForceField;
    public GameObject BlueForceField;

    [Space]
    [Header("Game UI Variants")]

    public GameObject MultidirectionalBall;
    public GameObject MultiDirectionalBallUI;
    public GameObject BallCount1;
    public GameObject BallCount2;
    public GameObject BallCount3;
    public GameObject BallCount4;
    public GameObject BallCount5;
    public GameObject BallCount6;
    public GameObject BallCount7;
    void Start()
    {
        GetComponents();
        IsStuck = true;
        shake = GameObject.FindGameObjectWithTag("ScreenShake").GetComponent<ShakeController>();
    }

    void Update()
    {
        Scene CurrentScene = SceneManager.GetActiveScene();

        string SceneName = CurrentScene.name;

        if (SceneName == "Level3")
        {
            if (MultiDirectionalBallUI.activeSelf)
            {
                if (AbilityCount <= 7)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(true);
                    BallCount7.SetActive(true);
                }
                if (AbilityCount <= 6)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(true);
                    BallCount7.SetActive(false);
                }

                if (AbilityCount <= 5)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }

                if (AbilityCount <= 4)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }
                if (AbilityCount <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }

                if (AbilityCount <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }

                if (AbilityCount <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }

                if (AbilityCount < 0)
                {
                    BallCount1.SetActive(false);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                    BallCount6.SetActive(false);
                    BallCount7.SetActive(false);
                }

                else
                {
                    if (IsStuck == true)
                    {
                        HandleMovement();
                    }
                }
            }
        }
    }

    void GetComponents()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        Cam = GetComponent<Camera>();

        playerVFX = GetComponent<PlayerVisualEffectsController>();
    }

    void HandleMovement()
    {
        //When mouse is clicked
        if (inputData.isPressed == true)
        {
            ClickedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            ClickedPosition = new Vector3(rigidBody.position.x, rigidBody.position.y, 0f);
            //ClickedPosition = new Vector3(ClickedPosition.x, ClickedPosition.y, 0f);

            //ResetPlayerPosition();

            //playerVFX.SetDotStartPosition(ClickedPosition);

            playerVFX.ActivateDotState(true);

            playerVFX.ChangeBallTrailState(false, 0f);

            Debug.Log(Input.mousePosition);
            Debug.Log(ClickedPosition);
        }

        //when mouse is clicked and held
        if (inputData.isHeld == true)
        {
            playerVFX.SetDotPosition(ClickedPosition, Camera.main.ScreenToWorldPoint(Input.mousePosition));
            playerVFX.MakeBallPulse();
        }

        //when mouse is released after being held
        if (inputData.isReleased == true)
        {
            ReleasedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            ReleasedPosition = new Vector3(ReleasedPosition.x, ReleasedPosition.y, 0f);
            Debug.Log(Input.mousePosition);
            Debug.Log(ReleasedPosition);

            playerVFX.ActivateDotState(false);
            playerVFX.ResetBallSize();

            playerVFX.ChangeBallTrailState(true, 0.7f);

            CalculateDirection();

            MovePlayerInDirection();

            IsStuck = false;
        }
    }

    //Claculate decision and power based on click and drag
    void CalculateDirection()
    {
        Direction = (ReleasedPosition - ClickedPosition).normalized;
    }

    //shoots ball in direction of choice
    void MovePlayerInDirection()
    {
        rigidBody.velocity = Direction * MovementSpeed;
    }

    //origninally resets player, but now it just stops player in place so line renderer still connects 
    void ResetPlayerPosition()
    {
        rigidBody.velocity = Vector3.zero;
    }
    ///void ResetPlayerPosition()
    ///{
    ///transform.position = ClickedPosition;
    ///rigidbody.velocity = Vector3.zero;
    ///}
    ///

    //if omniball collides with wall, ball stops and uses 1 ability point
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Base Wall"))
        {
            Vector2 NormalWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, NormalWall).normalized;

            rigidBody.velocity = Vector3.zero;

            AbilityCount--;

            IsStuck = true;

            Instantiate(Effect, transform.position, Quaternion.identity);

            shake.CamShake();
        }

        if (collision.gameObject.CompareTag("Breakable Wall"))
        {
            Vector2 BreakableWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, BreakableWall).normalized;

            rigidBody.velocity = Vector3.zero;

            AbilityCount--;

            IsStuck = true;

            Instantiate(Effect, transform.position, Quaternion.identity);

            shake.CamShake();
        }

        if (collision.gameObject.CompareTag("Normal Ball"))
        {
            Vector2 NormalBall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, NormalBall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }
    }

    bool HitBlockCheck()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit2D WallHit = Physics2D.Raycast(ray.origin, ray.direction, 100f, ColliderLayer);

        return WallHit;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("BlueForceField"))
        {
            BlueForceField.SetActive(false);
        }

        if (collision.gameObject.CompareTag("YellowForceField"))
        {
            YellowForceField.SetActive(false);
        }

        if (collision.gameObject.CompareTag("RedForceField"))
        {
            RedForceField.SetActive(false);
        }
    }
}
