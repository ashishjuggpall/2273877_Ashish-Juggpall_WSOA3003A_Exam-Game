 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public InputDataController inputData;

    public LayerMask ColliderLayer;

    private PlayerVisualEffectsController playerVFX;

    private GameManager gameManager;

    [Header("Game Object Variables")]
    public float MovementSpeed = 10f;

    private Vector3 ClickedPosition;
    private Vector3 ReleasedPosition;
    private Vector3 Direction;

    Rigidbody2D rigidBody;

    Camera Cam;

    public GameObject NormalBall;

    public int BallMoves = 3;

    public float VelocityTimeRemaining = 10f;
    public bool VelocityTimeRunning = false;

    public GameObject Effect;

    [Space]
    [Header("Endgame Targets")]
    public GameObject EndGame1;
    public GameObject EndGame2;
    public GameObject EndGame3;

    [Space]
    [Header("Game UI Variants")]
    public GameObject AllGameUI;
    public GameObject NormalBallUI;
    public GameObject BallCount1;
    public GameObject BallCount2;
    public GameObject BallCount3;
    public GameObject BallCount4;
    public GameObject BallCount5;

    [Space]
    [Header("Force Fields")]

    public GameObject RedForceField;
    public GameObject YellowForceField;
    public GameObject BlueForceField;

    [Space]
    [Header("Win & Lose UI")]
    public GameObject WinUI1;
    public GameObject LoseUI1;
    public GameObject WinUI2;
    public GameObject LoseUI2;
    public GameObject WinUI3;
    public GameObject LoseUI3;
    

    void Start()
    {
        GetComponents();
        VelocityTimeRunning = false;

        gameManager = GetComponent<GameManager>();
    }

    void Update()
    {
        Scene CurrentScene = SceneManager.GetActiveScene();

        string SceneName = CurrentScene.name;

        //if Level1 is active 
        if (SceneName == "Level1")
        {
            if (NormalBallUI.activeSelf)
            {
                if (BallMoves <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                }

                if (BallMoves <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                }

                if (BallMoves <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                }

                if (BallMoves < 0)
                {
                    GameLoss1();
                }

                else
                {
                    if (VelocityTimeRunning == false)
                    {
                        HandleMovement();
                    }
                }
            }
        }

        if (SceneName == "Level2")
        {
            if (NormalBallUI.activeSelf)
            {
                if (BallMoves <= 5)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                }

                if (BallMoves <= 4)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(false);
                }
                if (BallMoves <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves < 0)
                {
                    GameLoss2();
                }

                else
                {
                    if (VelocityTimeRunning == false)
                    {
                        HandleMovement();
                    }
                }
            }
        }

        if (SceneName == "Level3")
        {
            if (NormalBallUI.activeSelf)
            {
                if (BallMoves <= 5)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(true);
                }

                if (BallMoves <= 4)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(true);
                    BallCount5.SetActive(false);
                }
                if (BallMoves <= 3)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(true);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves <= 2)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(true);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves <= 1)
                {
                    BallCount1.SetActive(true);
                    BallCount2.SetActive(false);
                    BallCount3.SetActive(false);
                    BallCount4.SetActive(false);
                    BallCount5.SetActive(false);
                }

                if (BallMoves < 0)
                {
                    GameLoss3();
                }

                else
                {
                    if (VelocityTimeRunning == false)
                    {
                        HandleMovement();
                    }
                }
            }
        }
    }

    public void FixedUpdate()
    {
        if (VelocityTimeRunning)
        {
            if (VelocityTimeRemaining > 0)
            {
                VelocityTimeRemaining -= Time.deltaTime;
            }

            else
            {
                ResetPlayerPosition();
                VelocityTimeRemaining = 10f;
                VelocityTimeRunning = false;
            }
        }
    }

    void GetComponents()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        Cam = GetComponent<Camera>();

        playerVFX = GetComponent<PlayerVisualEffectsController>();

        
    }

    void HandleMovement()
    {
        //When mouse is clicked
        if(inputData.isPressed == true)
        {
            ClickedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            ClickedPosition = new Vector3(rigidBody.position.x, rigidBody.position.y, 0f);
            //ClickedPosition = new Vector3(ClickedPosition.x, ClickedPosition.y, 0f);

            //ResetPlayerPosition();
            ResetPlayerPosition();

            //playerVFX.SetDotStartPosition(ClickedPosition);

            playerVFX.ActivateDotState(true);

            playerVFX.ChangeBallTrailState(false, 0f);

            Debug.Log(Input.mousePosition);
            Debug.Log(ClickedPosition);
        }

        //when mouse is clicked and held
        if (inputData.isHeld == true)
        {
            playerVFX.SetDotPosition(ClickedPosition, Camera.main.ScreenToWorldPoint(Input.mousePosition));
            playerVFX.MakeBallPulse(); 
        }

        //when mouse is released after being held
        if (inputData.isReleased == true)
        {
            VelocityTimeRunning = true;
            ReleasedPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            ReleasedPosition = new Vector3(ReleasedPosition.x, ReleasedPosition.y, 0f);
            Debug.Log(Input.mousePosition);
            Debug.Log(ReleasedPosition);

            playerVFX.ActivateDotState(false);
            playerVFX.ResetBallSize();

            playerVFX.ChangeBallTrailState(true, 0.7f);

            CalculateDirection();

            MovePlayerInDirection();

            BallMoves--;
        }
    }

    //Claculate decision and power based on click and drag
    void CalculateDirection()
    {
        Direction = (ReleasedPosition - ClickedPosition).normalized;
    }

    //shoots ball in direction of choice
    void MovePlayerInDirection()
    {
        rigidBody.velocity = Direction * MovementSpeed;
    }

    //origninally resets player, but now it just stops player in place so line renderer still connects 
    void ResetPlayerPosition()
    {
        rigidBody.velocity = Vector3.zero;
    }
    ///void ResetPlayerPosition()
    ///{
    ///transform.position = ClickedPosition;
    ///rigidbody.velocity = Vector3.zero;
    ///}
    ///

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Scene CurrentScene = SceneManager.GetActiveScene();

        string SceneName = CurrentScene.name;

        if (collision.gameObject.CompareTag("Base Wall"))
        {
            Vector2 NormalWall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, NormalWall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }

        if (collision.gameObject.CompareTag("Breakable Wall"))
        {
            if (SceneName == "Level2")
            {
                GameLoss2();
            }

            if (SceneName == "Level3")
            {
                GameLoss3();
            }
        }

        if (collision.gameObject.CompareTag("MultiDirectional Ball"))
        {
            Vector2 MultiDirectionalBall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, MultiDirectionalBall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }

        if (collision.gameObject.CompareTag("Destructable Ball"))
        {
            Vector2 MultiDirectionalBall = collision.contacts[0].normal;
            Direction = Vector2.Reflect(rigidBody.velocity, MultiDirectionalBall).normalized;

            rigidBody.velocity = Direction * MovementSpeed;
        }
    }

    bool HitBlockCheck()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit2D WallHit = Physics2D.Raycast(ray.origin, ray.direction, 100f, ColliderLayer);

        return WallHit;
    }

    public void GameWon1()
    {
        AllGameUI.SetActive(false);
        WinUI1.SetActive(true);
    }

    public void GameLoss1()
    {
        AllGameUI.SetActive(false);
        LoseUI1.SetActive(true);
    }

    public void GameWon2()
    {
        AllGameUI.SetActive(false);
        WinUI2.SetActive(true);
    }
    public void GameLoss2()
    {
        AllGameUI.SetActive(false);
        LoseUI2.SetActive(true);
    }

    public void GameWon3()
    {
        AllGameUI.SetActive(false);
        WinUI3.SetActive(true);
    }
    public void GameLoss3()
    {
        AllGameUI.SetActive(false);
        LoseUI3.SetActive(true);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("EndGame1"))
        {
            Instantiate(Effect, transform.position, Quaternion.identity);
            GameWon1();
        }

        if (collision.gameObject.CompareTag("EndGame2"))
        {
            Instantiate(Effect, transform.position, Quaternion.identity);
            GameWon2();
        }

        if (collision.gameObject.CompareTag("EndGame3"))
        {
            Instantiate(Effect, transform.position, Quaternion.identity);
            GameWon3();
        }
        
        if (collision.gameObject.CompareTag("BlueForceField"))
        {
            BlueForceField.SetActive(false);
        }

        if (collision.gameObject.CompareTag("YellowForceField"))
        {
            YellowForceField.SetActive(false);
        }

        if (collision.gameObject.CompareTag("RedForceField"))
        {
            RedForceField.SetActive(false);
        }
    }
}
