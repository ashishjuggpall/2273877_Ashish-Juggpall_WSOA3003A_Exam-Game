using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    public static bool PausedGame = false;
    public GameObject PauseMenuUI;

    public GameObject Intro;
    public GameObject HowToPlay1;
    public GameObject HowToPlay2;
    public GameObject HowToPlay3;
    public GameObject HowToPlay4;
    public GameObject HowToPlay5;
    public GameObject HowToPlay6;

    //PauseMenu button
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (PausedGame)
            {
                Resume();
            }

            else
            {
                Pause();
            }
        }
    }

    public void Resume()
    {
        PauseMenuUI.SetActive(false);
        Time.timeScale = 1;
        PausedGame = false;
    }

    void Pause()
    {
        PauseMenuUI.SetActive(true);
        Time.timeScale = 0;
        PausedGame = true;
    }

    public void References()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(5);
    }

    public void HowToPlay()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(1);
    }

    public void LoadMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
    }

    public void PlayLevel1()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(2);
    }

    public void PlayLevel2()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(3);
    }

    public void PlayLevel3()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(4);
    }

    public void Quit()
    {
        Application.Quit();
        Debug.Log("Quit");
    }

    public void HowtoPlay1()
    {
        Intro.SetActive(false);
        HowToPlay1.SetActive(true);
    }
    public void HowtoPlay2()
    {
        HowToPlay1.SetActive(false);
        HowToPlay2.SetActive(true);
    }
    public void HowtoPlay3()
    {
        HowToPlay2.SetActive(false);
        HowToPlay3.SetActive(true);
    }
    public void HowtoPlay4()
    {
        HowToPlay3.SetActive(false);
        HowToPlay4.SetActive(true);
    }
    public void HowtoPlay5()
    {
        HowToPlay4.SetActive(false);
        HowToPlay5.SetActive(true);
    }

    public void HowtoPlay6()
    {
        HowToPlay5.SetActive(false);
        HowToPlay6.SetActive(true);
    }
}
